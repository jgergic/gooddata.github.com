Document the `alter.txt` script that demonstrates how to change the data model using the `GenerateUpdateMaql` command.
